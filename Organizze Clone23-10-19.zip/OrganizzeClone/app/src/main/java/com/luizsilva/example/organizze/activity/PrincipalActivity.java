package com.luizsilva.example.organizze.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.luizsilva.example.organizze.R;
import com.luizsilva.example.organizze.config.ConfiguracaoFirebase;
import com.luizsilva.example.organizze.databinding.ActivityPrincipalBinding;
import com.luizsilva.example.organizze.helper.Base64Custom;
import com.luizsilva.example.organizze.helper.DateCustom;
import com.luizsilva.example.organizze.model.Usuario;

import java.text.DecimalFormat;


public class PrincipalActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityPrincipalBinding binding;
    private TextView viewText, textSaudacao, textSaldo;
    private DatabaseReference firebaseRef = ConfiguracaoFirebase.getFirebaseDatabase();
    private FirebaseAuth auth = ConfiguracaoFirebase.getFirebaseAuth();
    private Double despesaTotal = 0.0;
    private Double receitaTotal = 0.0;
    private Double resumousuario = 0.0;
    private DatabaseReference userRef;
    private ValueEventListener valueEventListenerUsuario;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityPrincipalBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        textSaudacao = findViewById(R.id.textSaudacao);
        textSaldo = findViewById(R.id.textSaldo);

        viewText = findViewById(R.id.txtDataExibir);
        viewText.setText(DateCustom.dateShowUser());

        setSupportActionBar(binding.toolbar);
        binding.toolbar.setTitle("Organizze");


        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_principal);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

    }

    @Override
    protected void onStart() {
        super.onStart();
        recuperarResumo();
    }

    public void recuperarResumo(){
        String emailUsuario =  auth.getCurrentUser().getEmail();
        String idUsuario = Base64Custom.codeBase64(emailUsuario);
        userRef= firebaseRef.child("usuario").child(idUsuario);
        valueEventListenerUsuario = userRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                Usuario usuario = snapshot.getValue(Usuario.class);

                despesaTotal = usuario.getDespesaTotal();
                receitaTotal = usuario.getReceitaTotal();

                resumousuario = receitaTotal - despesaTotal;

                DecimalFormat df = new DecimalFormat("0.##");
                String resultFormatado = df.format(resumousuario);

                textSaudacao.setText("Olá, " + usuario.getNome());
                textSaldo.setText("R$ " + resultFormatado);
                Log.i("Resultado", resultFormatado);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_principal, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menuSair :
                auth.signOut();
                startActivity(new Intent(this, MainActivity.class));
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_principal);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }


    public void adicionarDespesa(View view){

        startActivity(new Intent(this,DespesasActivity.class));

    }

    public void adicionarReceita(View view){
        startActivity(new Intent(this,ReceitasActivity.class));

    }

    public void beforeClick(View view){

        Toast.makeText(this, "Data Selecionada Firebase: "+DateCustom.dateFirebase(0), Toast.LENGTH_SHORT).show();
        viewText.setText(DateCustom.dateShowUser());
    }

    public void afterClick(View view){

        Toast.makeText(this, "Data Selecionada Firebase: "+DateCustom.dateFirebase(1), Toast.LENGTH_SHORT).show();
        viewText.setText(DateCustom.dateShowUser());
    }

    @Override
    protected void onStop() {
        super.onStop();
        userRef.removeEventListener(valueEventListenerUsuario);
    }
}